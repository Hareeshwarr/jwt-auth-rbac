import { useEffect, useState } from "react";
import { getUserData } from "../api/dashboardService";

export default function UserDashboard() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getUserData()
      .then((res) => setMessage(res.data))
      .catch(() => setError("Access denied"));
  }, []);

  return (
    <div>
      <h1>User Dashboard</h1>

      {message && <p style={{ color: "green" }}>{message}</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
