import { useEffect, useState } from "react";
import { getAdminData } from "../api/dashboardService.js";

export default function AdminDashboard() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getAdminData()
      .then((res) => setMessage(res.data))
      .catch(() => setError("Access denied"));
  }, []);

  return (
    <div>
      <h1>Admin Dashboard</h1>

      {message && <p style={{ color: "green" }}>{message}</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
