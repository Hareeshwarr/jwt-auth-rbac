import { useEffect, useState } from "react";
import { getModeratorData } from "../api/dashboardService";

export default function ModeratorDashboard() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    getModeratorData()
      .then((res) => setMessage(res.data))
      .catch(() => setError("Access denied"));
  }, []);

  return (
    <div>
      <h1>Moderator Dashboard</h1>

      {message && <p style={{ color: "green" }}>{message}</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
